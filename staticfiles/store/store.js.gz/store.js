$(document).ready(function () {
    // Handler for .ready() called.
    $(".dropdown-trigger").dropdown({ "hover": true });
    $('.materialboxed').materialbox();
    $('.sidenav').sidenav();
});