$(document).ready(function () {
    // Handler for .ready() called.
    $(".dropdown-trigger").dropdown({ "hover": false });
    $('.materialboxed').materialbox();
    $('.sidenav').sidenav();
});